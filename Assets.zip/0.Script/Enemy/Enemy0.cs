using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy0 : Enemy
{
    void Start()
    {
        Speed = 0.2f;
    }

}
