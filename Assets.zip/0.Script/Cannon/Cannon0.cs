using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannon0 : Cannon
{
    // Start is called before the first frame update
    void Start()
    {
        AttDistance = 3f;
        AttDelay = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
